#!/bin/bash
#========================#
# By UKAz-XDA 25/10/2023 #
#    (C) K Y U B E Y     #
#========================#

exec 2> /dev/null
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================
"
function KYU() {

> Kyudata; chmod 777 Kyudata
> Kyubey; chmod 777 Kyubey
> Kyutmp; chmod 777 Kyutmp
> Kyuload; chmod 777 Kyuload
echo "#!/bin/bash
#========================#
# By UKAz-XDA 25/10/2023 #
#    (C) K Y U B E Y     #
#========================#
exec 2> /dev/null
function KYU() {
$2
}
#========================#
#          DATA          #
#========================#
" >> Kyubey
echo "function KYU() {
echo "'"SUBE=$SUBE;FILE=$FILE; KYU"'" >> Kyubey
}" > Kyutmp

ls -R -F -Z $1 >> Kyuload
awk '!/\?/ || !/\//' Kyuload > Kyudata
rm Kyuload
sed -i 's/'$3'\//SUBE='"'"'"/g' Kyudata
sed -i 's/:/\/"'"'"'/g' Kyudata
sed -i '1d' Kyudata
sed -i 's/? /FILE='"'"'"/g' Kyudata
sed -i 's/*/"'"'"'; KYU/g' Kyudata
cat Kyudata >> Kyutmp; rm Kyudata
chmod 777 Kyutmp; bash Kyutmp; rm Kyutmp
chmod 777 Kyubey; bash Kyubey

}
#===================================================#
# LS <DIRETORIO QUE SERÁ LISTADO>
# CODE <CODIGO QUE SERÁ EXECUTADO SOBRE A LISTA>
# KYU <CRIARA O EXECUTAVEL> <KYU "$LS" "$CODE" "$FIX"> $SUBE$FILE
#===================================================#
# ALVO "LIB" e "ETC"

mkdir TREBLE
mkdir NONTRE
chmod -R 777 *

LS="NONTRE/system/lib"
FIX="NONTRE\/system\/lib"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================
  NONTRE/system/lib
  Loading.. $FILE
"
	mkdir -p TREBLE/system/lib/$SUBE
	mv -n TREBLE/system/vendor/lib/$SUBE$FILE TREBLE/system/lib/$SUBE$FILE
'
KYU "$LS" "$CODE" "$FIX"

LS="NONTRE/system/vendor/lib"
FIX="NONTRE\/system\/vendor\/lib"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================
  NONTRE/system/vendor/lib
  Loading.. $FILE
"
	mkdir -p TREBLE/system/vendor/lib/$SUBE
	mv -n TREBLE/system/lib/$SUBE$FILE TREBLE/system/vendor/lib/$SUBE$FILE
'
KYU "$LS" "$CODE" "$FIX"

LS="NONTRE/system/etc"
FIX="NONTRE\/system\/etc"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================
  NONTRE/system/etc
  Loading.. $FILE
"
	mkdir -p TREBLE/system/etc/$SUBE
	mv -n TREBLE/system/vendor/etc/$SUBE$FILE TREBLE/system/etc/$SUBE$FILE
'
KYU "$LS" "$CODE" "$FIX"

LS="NONTRE/system/vendor/etc"
FIX="NONTRE\/system\/vendor\/etc"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================
  NONTRE/system/vendor/etc
  Loading.. $FILE
"
	mkdir -p TREBLE/system/vendor/etc/$SUBE
	mv -n TREBLE/system/etc/$SUBE$FILE TREBLE/system/vendor/etc/$SUBE$FILE
'
KYU "$LS" "$CODE" "$FIX"
