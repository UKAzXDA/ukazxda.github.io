#!/bin/bash
#========================#
# By UKAz-XDA 25/10/2023 #
#    (C) K Y U B E Y     #
#========================#

exec 2> /dev/null
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================
"
function KYU() {

> Kyudata; chmod 777 Kyudata
> Kyubey; chmod 777 Kyubey
> Kyutmp; chmod 777 Kyutmp
> Kyuload; chmod 777 Kyuload
echo "#!/bin/bash
#========================#
# By UKAz-XDA 25/10/2023 #
#    (C) K Y U B E Y     #
#========================#
exec 2> /dev/null
function KYU() {
$2
}
#========================#
#          DATA          #
#========================#
" >> Kyubey
echo "function KYU() {
echo "'"SUBE=$SUBE;FILE=$FILE; KYU"'" >> Kyubey
}" > Kyutmp

ls -R -F -Z $1 >> Kyuload
awk '!/\?/ || !/\//' Kyuload > Kyudata
rm Kyuload
sed -i 's/'$1'\//SUBE='"'"'"/g' Kyudata
sed -i 's/:/\/"'"'"'/g' Kyudata
sed -i '1d' Kyudata
sed -i 's/? /FILE='"'"'"/g' Kyudata
sed -i 's/*/"'"'"'; KYU/g' Kyudata
cat Kyudata >> Kyutmp; rm Kyudata
chmod 777 Kyutmp; bash Kyutmp; rm Kyutmp
chmod 777 Kyubey; bash Kyubey

}
#===================================================#
# LS <DIRETORIO QUE SERÁ LISTADO>
# CODE <CODIGO QUE SERÁ EXECUTADO SOBRE A LISTA>
# KYU <CRIARA O EXECUTAVEL> <KYU "$LS" "$CODE">
#===================================================#
				    # G610M #

mkdir ORO_G610M
mkdir PIE_G611M

mkdir IGU_FILES
mkdir ADD_G610M
mkdir ADD_G611M
chmod -R 777 *

LS="ORO_G610M"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================

  OREO G610M e PIE G611M
  Comparando sube pastas: $SUBE
  Loading: $FILE
"
if [ "`cat PIE_G611M/$SUBE$FILE`" = "`cat ORO_G610M/$SUBE$FILE`" ]; then
	mkdir -p IGU_FILES/$SUBE
	cp "ORO_G610M/$SUBE$FILE" "IGU_FILES/$SUBE$FILE"
		else
	echo
fi 
'
KYU "$LS" "$CODE"

LS="PIE_G611M"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================

  PIE G611M
  Encontrando sube pastas: $SUBE
  Loading: $FILE
"
if [ -e ORO_G610M/$SUBE$FILE ]; then
	echo
else
	mkdir -p ADD_G611M/$SUBE
	cp "PIE_G611M/$SUBE$FILE" "ADD_G611M/$SUBE$FILE"
fi
'
KYU "$LS" "$CODE"

LS="ORO_G610M"
CODE='
clear
echo "
  ======================================
  =   By UKAz-XDA  v7.0  Modo: cat     =
  =  Script para comparar arquivos.    =
  =  Busca por arquivos subistituidos. =
  =    v7.0 Suporte para Subpastas     =
  ======================================

  OREO G610M
  Encontrando sube pastas: $SUBE
  Loading: $FILE
"
if [ -e PIE_G611M/$SUBE$FILE ]; then
	echo
else
	mkdir -p ADD_G610M/$SUBE
	cp "ORO_G610M/$SUBE$FILE" "ADD_G610M/$SUBE$FILE"
fi
'
KYU "$LS" "$CODE"
echo "
Feito!
"
